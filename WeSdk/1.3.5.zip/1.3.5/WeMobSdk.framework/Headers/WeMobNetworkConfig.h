//
//  WeMobNetworkConfig.h
//  WeMobSdk
//
//  Created by Matthew on 2019/10/8.
//  Copyright © 2019年 WeMob. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WeMobNetworkConfig : NSObject

-(void)log:(NSString *)message;

@end
