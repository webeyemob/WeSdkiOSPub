//
//  WeMobMediation_Maio.h
//  WeMobMediation_Maio
//
//  Created by Mathew on 2019/6/27.
//  Copyright © 2019年 WeSdk. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for WeMobMediation_Maio.
FOUNDATION_EXPORT double WeMobMediation_MaioVersionNumber;

//! Project version string for WeMobMediation_Maio.
FOUNDATION_EXPORT const unsigned char WeMobMediation_MaioVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WeMobMediation_Maio/PublicHeader.h>


