//
//  WeMobNendVideoNative.h
//  WeMobMediation_Nend
//
//  Created by Mathew on 2019/6/28.
//  Copyright © 2019年 WeSdk. All rights reserved.
//

#import "WeMobBaseNative.h"
#import <NendAd/NendAd.h>

@interface WeMobNendVideoNative : WeMobBaseNative<NADNativeVideoDelegate, NADNativeVideoViewDelegate>

@end
