//
//  WeMobNendRewardedVideo.h
//  WeMobMediation_Nend
//
//  Created by Mathew on 2019/6/28.
//  Copyright © 2019年 WeSdk. All rights reserved.
//

#import "WeMobCustomRewardedVideo.h"
#import <NendAd/NendAd.h>

@interface WeMobNendRewardedVideo : WeMobCustomRewardedVideo<NADRewardedVideoDelegate>

@end
