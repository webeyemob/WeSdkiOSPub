//
//  WeMobMediation_Chartboost.h
//  WeMobMediation_Chartboost
//
//  Created by 汤正 on 2019/8/5.
//  Copyright © 2019 WeMob. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for WeMobMediation_Chartboost.
FOUNDATION_EXPORT double WeMobMediation_ChartboostVersionNumber;

//! Project version string for WeMobMediation_Chartboost.
FOUNDATION_EXPORT const unsigned char WeMobMediation_ChartboostVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WeMobMediation_Chartboost/PublicHeader.h>


