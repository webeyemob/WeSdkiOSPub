//
//  WeMobMediation_GoogleAds.h
//  WeMobMediation_GoogleAds
//
//  Created by Mathew on 2018/9/13.
//

#import <UIKit/UIKit.h>

//! Project version number for WeMobMediation_GoogleAds.
FOUNDATION_EXPORT double WeMobMediation_GoogleAdsVersionNumber;

//! Project version string for WeMobMediation_GoogleAds.
FOUNDATION_EXPORT const unsigned char WeMobMediation_GoogleAdsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WeMobMediation_GoogleAds/PublicHeader.h>
