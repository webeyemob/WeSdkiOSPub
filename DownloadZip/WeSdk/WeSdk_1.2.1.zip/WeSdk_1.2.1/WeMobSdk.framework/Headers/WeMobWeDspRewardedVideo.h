//
//  WeMobWeDspRewardedVideo.h
//  Mediation_WeDsp
//

#import "WeMobCustomRewardedVideo.h"


@interface WeMobWeDspRewardedVideo : WeMobCustomRewardedVideo

@end
