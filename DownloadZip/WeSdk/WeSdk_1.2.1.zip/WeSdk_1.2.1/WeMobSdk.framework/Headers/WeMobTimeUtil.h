//
//  WeMobTimeUtil.h

//
//  Created by Mathew on 2019/6/17.
//

@interface WeMobTimeUtil : NSObject

+(long long)getDateTimeMilliSeconds;

@end
