//
//  WeMobAdMobBanner.h
//  WeMobMediation_GoogleAds
//

#import "WeMobCustomBanner.h"


@interface WeMobWeDspBanner : WeMobCustomBanner

@end
