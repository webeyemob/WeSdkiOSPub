//
//  WeMobUnityInterstitial.h
//  WeMobMediation_UnityAds
//

#import "WeMobCustomInterstitial.h"
#import "UnityAds/UnityAds.h"

@interface WeMobUnityInterstitial : WeMobCustomInterstitial<UnityMonetizationDelegate,UMONShowAdDelegate>

@end
