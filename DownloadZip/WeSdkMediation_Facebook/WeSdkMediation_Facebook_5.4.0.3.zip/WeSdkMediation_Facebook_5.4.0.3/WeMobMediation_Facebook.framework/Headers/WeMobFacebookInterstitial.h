//
//  WeMobFacebookInterstitial.h
//  WeMobMediation_Facebook
//

#import "WeMobCustomInterstitial.h"
#import <FBAudienceNetwork/FBAudienceNetwork.h>

@interface WeMobFacebookInterstitial : WeMobCustomInterstitial<FBInterstitialAdDelegate>

@end
