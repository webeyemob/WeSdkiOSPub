//
//  WeMobFacebookNative.h
//  WeMobMediation_Facebook
//
//  Created by Mathew on 2019/6/23.
//

#import <UIKit/UIKit.h>
#import "WeMobCustomNative.h"
#import <FBAudienceNetwork/FBAudienceNetwork.h>

@interface WeMobFacebookNative : WeMobCustomNative<FBNativeAdDelegate>

@end
