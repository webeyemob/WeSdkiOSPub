//
//  WeMobMediation_TikTok.h
//  WeMobMediation_TikTok
//
//  Created by Mathew on 2019/7/3.
//  Copyright © 2019年 WeMob. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for WeMobMediation_TikTok.
FOUNDATION_EXPORT double WeMobMediation_TikTokVersionNumber;

//! Project version string for WeMobMediation_TikTok.
FOUNDATION_EXPORT const unsigned char WeMobMediation_TikTokVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WeMobMediation_TikTok/PublicHeader.h>

#import <WeMobMediation_TikTok/WeMobTikTokExpressFeedListConfig.h>
#import <WeMobMediation_TikTok/WeMobTikTokSplashConfig.h>
